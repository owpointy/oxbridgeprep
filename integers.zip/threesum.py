def threesum (file):
    f= open(file,"r")
    #splits f into string
    f=f.read().split()
    #makes array
    print('making array')
    array = [int(x) for x in f]
    print('done')
    #prints cmbinations of outputs
    n = len(array)
    i=0
    j=0
    print('checking numbers')
    while i < n:
        j=i+1
        while j < n:
                allnums1 = array[j]
                allnums2=array[i]
                #checks if sum of allnums 1 and 2 is in array - this is CRITICALLY IMPORTANT
                if (allnums1 + allnums2) in array:
                    print(allnums1,',',allnums2)
                
                j+=1
        i+=1
    print('done')
threesum('integers.txt')
